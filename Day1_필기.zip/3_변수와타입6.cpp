#include <iostream>
#include <cstring>

int main()
{
	char s1[] = "ABCD";
	char s2[10];

	s2 = s1;

	if ( s1 == s2 ) {}
}