﻿// 6_STL
#include <iostream>
#include <stack>
#include <vector>
#include <string>  

int main()
{
	char s1[10] = "hello";
	char s2[10] = "hello";
	if (s1 == s2) {}
}

